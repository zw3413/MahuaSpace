# manga


action list :

+ before_manga_single
+ after_manga_single
+ wp_manga_discussion
+ wp_manga_single_sidebar
+ wp_manga_read_sidebar
+ wp_manga_archive_sidebar